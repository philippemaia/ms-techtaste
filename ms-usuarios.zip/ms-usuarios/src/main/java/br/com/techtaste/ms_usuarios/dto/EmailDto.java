package br.com.techtaste.ms_usuarios.dto;

public record EmailDto(String cpf,
                       String pedidoId,
                       String status) {
}
