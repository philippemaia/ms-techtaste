INSERT INTO usuarios (cpf, nome, email)
VALUES
('123.456.789-00', 'João Silva', 'joao.silva@email.com'),
('987.654.321-00', 'Maria Oliveira', 'maria.oliveira@email.com'),
('111.222.333-44', 'Carlos Pereira', 'carlos.pereira@email.com');